export interface User {
  id: number;
  name: string;
  email: string;
  created_at: string;
}

export type CreateUserData = Pick<User, 'name' | 'email'>;
export type UpdateUserData = Partial<CreateUserData>;