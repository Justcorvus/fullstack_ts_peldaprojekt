# Használt Modulok (Függőségek)

Ez a dokumentum bemutatja a projekt során felhasznált legfontosabb külső csomagokat (modulokat), azok célját és működését.

## Frontend Modulok

### 1. React (`react`, `react-dom`)
- **Hol használtuk?** A teljes frontend felület felépítéséhez.
- **Miért használtuk?** Komponens-alapú architektúrát biztosít.
- **Hogyan működik?** A Virtuális DOM segítségével hatékonyan frissíti a felületelemeket.

### 2. React Router (`react-router-dom`)
- **Hol használtuk?** Az `App.jsx`-ben és a `Navbar.jsx`-ben.
- **Miért használtuk?** Single Page Application (SPA) navigáció megvalósítására az oldal újratöltése nélkül.
- **Hogyan működik?** Figyeli az URL sávot, és a megfelelő komponenst rendereli.

### 3. Axios (`axios`)
- **Hol használtuk?** A `HomePage.jsx` komponensben.
- **Miért használtuk?** HTTP kérések (GET, POST, PATCH, DELETE) küldésére a backend szerver felé.
- **Hogyan működik?** Aszinkron kéréseket indít, automatikusan JSON-ná alakítja az adatokat és a választ.

### 4. React Markdown (`react-markdown`)
- **Hol használtuk?** A `CoursePage.jsx` komponensben.
- **Miért használtuk?** A Markdown dokumentumok formázott megjelenítésére.
- **Hogyan működik?** Beolvassa a nyers Markdown szöveget és HTML elemekké fordítja azt.

### 5. Bootstrap (`bootstrap`)
- **Hol használtuk?** A teljes alkalmazás stílusozásához.
- **Miért használtuk?** Gyors és reszponzív UI kialakítását teszi lehetővé egyedi CSS írása nélkül.
- **Hogyan működik?** Kész CSS osztályokat biztosít elrendezéshez és tipográfiához.

## Backend Modulok

### 1. Express (`express`)
- **Hol használtuk?** A `server.js` fájlban.
- **Miért használtuk?** Webszerver és API végpontok egyszerű létrehozására.
- **Hogyan működik?** Hallgat a megadott porton, fogadja a bejövő HTTP kéréseket és válaszol rájuk.

### 2. MySQL2 (`mysql2/promise`)
- **Hol használtuk?** A `server.js` fájlban az adatbázis kapcsolathoz.
- **Miért használtuk?** A Node.js és a MySQL kommunikációjához.
- **Hogyan működik?** SQL parancsokat küld a Promise API használatával, modern, aszinkron módon (`async/await`).

### 3. Dotenv (`dotenv`)
- **Hol használtuk?** A `server.js` fájl legelején.
- **Miért használtuk?** Érzékeny adatok (jelszavak, portok) biztonságos tárolására egy külső fájlban.
- **Hogyan működik?** Beolvassa a `.env` fájlt és betölti a változókat a környezetbe (`process.env`).

### 4. CORS (`cors`)
- **Hol használtuk?** A `server.js` fájlban middleware-ként.
- **Miért használtuk?** Hogy a frontend (`localhost:5173`) biztonságosan elérhesse a backendet (`localhost:3001`).
- **Hogyan működik?** Megfelelő HTTP fejléceket illeszt a backend válaszaihoz.

### 5. Jest és Supertest (`jest`, `supertest`)
- **Hol használtuk?** A `tests/` könyvtár fájljaiban (`server.test.js`).
- **Miért használtuk?** A kód automatizált tesztelésére.
- **Hogyan működik?** A Jest adja a tesztfuttató környezetet, a Supertest pedig szimulált HTTP kéréseket küld.